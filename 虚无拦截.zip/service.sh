
# 等待彻底开机完成
until [ "$(getprop init.svc.bootanim)" = "stopped" ]; do
	sleep 5
done
while [ ! -d "/sdcard/Android" ]; do
	sleep 5
done

# 测试网络
while :; do
	p=$(ping -c 1 -w 5 www.baidu.com | grep -c 'ms')
	[ $p != 0 ] && break
done

curl -o /data/adb/modules/AD_lite/ADhosts https://dev.iw233.cn/Lucky/Sbhosts.php
dd if=/data/adb/modules/AD_lite/ADhosts of=/system/etc/hosts 
setprop net.dns1 223.5.5.5
setprop net.dns2 223.6.6.6
